let hours_worked = [25; 25; 25; 25]
